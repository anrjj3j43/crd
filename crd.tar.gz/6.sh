sudo apt install --assume-yes task-xfce-desktop
