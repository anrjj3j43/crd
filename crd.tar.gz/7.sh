sudo systemctl disable lightdm.service
