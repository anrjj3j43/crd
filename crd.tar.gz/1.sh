sudo apt update
sudo apt install --assume-yes wget tasksel
